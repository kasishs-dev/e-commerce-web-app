const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { protect, admin } = require('../middleware/authMiddleware');
const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: function (req, file, cb) {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

// @desc    Get products with advanced filtering, searching, and sorting
// @route   GET /api/products
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      keyword,
      category,
      brand,
      minPrice,
      maxPrice,
      rating,
      sortBy,
      page = 1,
      limit = 20,
      searchType = 'all' // 'all', 'name', 'description', 'category', 'brand'
    } = req.query;

    console.log('Received query parameters:', req.query);

    // Build filter object
    let filter = { isActive: true };

    // Advanced keyword search with multiple fields
    if (keyword && keyword.trim()) {
      const searchTerm = keyword.trim();
      
      switch (searchType) {
        case 'name':
          filter.name = { $regex: searchTerm, $options: 'i' };
          break;
        case 'description':
          filter.description = { $regex: searchTerm, $options: 'i' };
          break;
        case 'category':
          filter.category = { $regex: searchTerm, $options: 'i' };
          break;
        case 'brand':
          filter.brand = { $regex: searchTerm, $options: 'i' };
          break;
        case 'all':
        default:
          // Full-text search across multiple fields with weighted scoring
          filter.$or = [
            { name: { $regex: searchTerm, $options: 'i' } },
            { description: { $regex: searchTerm, $options: 'i' } },
            { category: { $regex: searchTerm, $options: 'i' } },
            { brand: { $regex: searchTerm, $options: 'i' } },
            { tags: { $in: [new RegExp(searchTerm, 'i')] } } // If you add tags field
          ];
          break;
      }
    }

    // Category filter
    if (category && category !== 'all') {
      filter.category = category;
    }

    // Brand filter
    if (brand && brand !== 'all') {
      filter.brand = brand;
    }

    // Price range filter
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = parseFloat(minPrice);
      if (maxPrice) filter.price.$lte = parseFloat(maxPrice);
    }

    // Rating filter
    if (rating) {
      filter.rating = { $gte: parseFloat(rating) };
    }

    console.log('Built filter object:', JSON.stringify(filter, null, 2));

    // Build sort object with advanced sorting options
    let sort = {};
    switch (sortBy) {
      case 'price_asc':
        sort.price = 1;
        break;
      case 'price_desc':
        sort.price = -1;
        break;
      case 'rating':
        sort.rating = -1;
        break;
      case 'popularity':
        sort.numReviews = -1;
        break;
      case 'newest':
        sort.createdAt = -1;
        break;
      case 'oldest':
        sort.createdAt = 1;
        break;
      case 'name_asc':
        sort.name = 1;
        break;
      case 'name_desc':
        sort.name = -1;
        break;
      case 'relevance':
        // For text search, we'll use text score if available
        if (keyword) {
          sort.score = { $meta: 'textScore' };
        } else {
          sort.createdAt = -1;
        }
        break;
      default:
        sort.createdAt = -1;
        break;
    }

    console.log('Sort object:', sort);

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query with aggregation for better performance
    let pipeline = [
      { $match: filter },
      { $sort: sort }
    ];

    // Add text score for relevance sorting
    if (keyword && sortBy === 'relevance') {
      pipeline.unshift({
        $addFields: {
          score: { $meta: 'textScore' }
        }
      });
    }

    // Add pagination
    pipeline.push(
      { $skip: skip },
      { $limit: parseInt(limit) }
    );

    const products = await Product.aggregate(pipeline);

    // Get total count for pagination (separate query for better performance)
    const totalProducts = await Product.countDocuments(filter);

    // Get aggregation data for filters
    const aggregationData = await Product.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: null,
          categories: { $addToSet: '$category' },
          brands: { $addToSet: '$brand' },
          minPrice: { $min: '$price' },
          maxPrice: { $max: '$price' },
          avgRating: { $avg: '$rating' }
        }
      }
    ]);

    const filterStats = aggregationData[0] || {
      categories: [],
      brands: [],
      minPrice: 0,
      maxPrice: 0,
      avgRating: 0
    };

    console.log(`Found ${products.length} products out of ${totalProducts} total`);

    res.json({
      products,
      totalProducts,
      currentPage: parseInt(page),
      totalPages: Math.ceil(totalProducts / parseInt(limit)),
      hasNextPage: skip + products.length < totalProducts,
      hasPrevPage: parseInt(page) > 1,
      filterStats: {
        categories: filterStats.categories.sort(),
        brands: filterStats.brands.sort(),
        priceRange: {
          min: filterStats.minPrice,
          max: filterStats.maxPrice
        },
        avgRating: Math.round(filterStats.avgRating * 10) / 10
      }
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// @desc    Get search suggestions (for autocomplete)
// @route   GET /api/products/search/suggestions
// @access  Public
router.get('/search/suggestions', async (req, res) => {
  try {
    const { q } = req.query;
    
    if (!q || q.length < 2) {
      return res.json({ suggestions: [] });
    }

    const suggestions = await Product.aggregate([
      {
        $match: {
          isActive: true,
          $or: [
            { name: { $regex: q, $options: 'i' } },
            { category: { $regex: q, $options: 'i' } },
            { brand: { $regex: q, $options: 'i' } }
          ]
        }
      },
      {
        $group: {
          _id: null,
          names: { $addToSet: '$name' },
          categories: { $addToSet: '$category' },
          brands: { $addToSet: '$brand' }
        }
      },
      {
        $project: {
          suggestions: {
            $concatArrays: [
              { $slice: ['$names', 5] },
              { $slice: ['$categories', 3] },
              { $slice: ['$brands', 3] }
            ]
          }
        }
      }
    ]);

    const result = suggestions[0]?.suggestions || [];
    res.json({ suggestions: result.slice(0, 10) });
  } catch (error) {
    console.error('Error fetching suggestions:', error);
    res.status(500).json({ error: 'Failed to fetch suggestions' });
  }
});

// @desc    Get all products (admin only) - including soft deleted
// @route   GET /api/products/admin
// @access  Private/Admin
router.get('/admin', protect, admin, async (req, res) => {
  try {
    const { includeDeleted = 'false' } = req.query;
    const filter = includeDeleted === 'true' ? {} : { isActive: true };
    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching admin products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// @desc    Get single product by ID
// @route   GET /api/products/:id
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Create new product
// @route   POST /api/products
// @access  Private/Admin
router.post('/', protect, admin, upload.single('image'), async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      category,
      brand,
      countInStock,
      rating = 0,
      numReviews = 0
    } = req.body;

    // Validate required fields
    if (!name || !description || !price || !category || !brand || !countInStock) {
      return res.status(400).json({ 
        message: 'Please provide all required fields: name, description, price, category, brand, countInStock' 
      });
    }

    // Validate price
    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum < 0) {
      return res.status(400).json({ message: 'Price must be a valid positive number' });
    }

    // Validate countInStock
    const stockNum = parseInt(countInStock);
    if (isNaN(stockNum) || stockNum < 0) {
      return res.status(400).json({ message: 'Count in stock must be a valid non-negative number' });
    }

    // Create product object
    const productData = {
      name: name.trim(),
      description: description.trim(),
      price: priceNum,
      category: category.trim(),
      brand: brand.trim(),
      countInStock: stockNum,
      rating: parseFloat(rating) || 0,
      numReviews: parseInt(numReviews) || 0,
      isActive: true
    };

    // Add image if uploaded
    if (req.file) {
      productData.image = `/uploads/${req.file.filename}`;
    }

    // Create product
    const product = new Product(productData);
    await product.save();

    res.status(201).json({
      message: 'Product created successfully',
      product
    });

  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ 
      message: error.message || 'Failed to create product' 
    });
  }
});

// @desc    Update product
// @route   PUT /api/products/:id
// @access  Private/Admin
router.put('/:id', protect, admin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Soft delete product (set isActive to false)
// @route   DELETE /api/products/:id
// @access  Private/Admin
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    // Soft delete - set isActive to false
    product.isActive = false;
    await product.save();
    
    res.json({ message: 'Product soft deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Restore soft deleted product
// @route   PUT /api/products/:id/restore
// @access  Private/Admin
router.put('/:id/restore', protect, admin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    // Restore product - set isActive to true
    product.isActive = true;
    await product.save();
    
    res.json({ message: 'Product restored successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Hard delete product (permanent deletion)
// @route   DELETE /api/products/:id/hard
// @access  Private/Admin
router.delete('/:id/hard', protect, admin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    await Product.deleteOne({ _id: req.params.id });
    res.json({ message: 'Product permanently deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Get filter options (categories and brands)
// @route   GET /api/products/filters/options
// @access  Public
router.get('/filters/options', async (req, res) => {
  try {
    const categories = await Product.distinct('category', { isActive: true });
    const brands = await Product.distinct('brand', { isActive: true });
    
    res.json({ categories, brands });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;