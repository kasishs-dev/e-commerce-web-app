// backend/routes/cart.js
const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const User = require('../models/User');

const router = express.Router();

// @desc    Get user cart
// @route   GET /api/cart
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('cart.items.product');
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Add item to cart
// @route   POST /api/cart
// @access  Private
router.post('/', protect, async (req, res) => {
  try {
    const { productId, quantity, name, price, image } = req.body;
    
    const user = await User.findById(req.user._id);
    const existingItem = user.cart.items.find(item => item.product.toString() === productId);

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      user.cart.items.push({
        product: productId,
        quantity,
        name,
        price,
        image
      });
    }

    user.cart.totalPrice = user.cart.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    user.cart.totalItems = user.cart.items.reduce((total, item) => total + item.quantity, 0);

    await user.save();
    await user.populate('cart.items.product');
    
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Update cart item quantity
// @route   PUT /api/cart/:itemId
// @access  Private
router.put('/:itemId', protect, async (req, res) => {
  try {
    const { quantity } = req.body;
    const user = await User.findById(req.user._id);
    const cartItem = user.cart.items.id(req.params.itemId);

    if (cartItem) {
      cartItem.quantity = quantity;
      
      user.cart.totalPrice = user.cart.items.reduce((total, item) => total + (item.price * item.quantity), 0);
      user.cart.totalItems = user.cart.items.reduce((total, item) => total + item.quantity, 0);

      await user.save();
      await user.populate('cart.items.product');
      
      res.json(user.cart);
    } else {
      res.status(404).json({ message: 'Cart item not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Remove item from cart
// @route   DELETE /api/cart/:itemId
// @access  Private
router.delete('/:itemId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.cart.items = user.cart.items.filter(item => item._id.toString() !== req.params.itemId);
    
    user.cart.totalPrice = user.cart.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    user.cart.totalItems = user.cart.items.reduce((total, item) => total + item.quantity, 0);

    await user.save();
    await user.populate('cart.items.product');
    
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Clear cart
// @route   DELETE /api/cart
// @access  Private
router.delete('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.cart = { items: [], totalPrice: 0, totalItems: 0 };
    await user.save();
    
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;