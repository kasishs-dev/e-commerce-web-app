// services/cartService.js
import { api } from './api';

// Get user cart
export const getCart = async () => {
  try {
    const response = await api.get('/cart');
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to fetch cart');
  }
};

// Add item to cart
export const addToCart = async (cartItem) => {
  try {
    const response = await api.post('/cart', cartItem);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to add to cart');
  }
};

// Update cart item quantity
export const updateCartItem = async (itemId, quantity) => {
  try {
    const response = await api.put(`/cart/${itemId}`, { quantity });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to update cart');
  }
};

// Remove item from cart
export const removeCartItem = async (itemId) => {
  try {
    const response = await api.delete(`/cart/${itemId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to remove from cart');
  }
};

// Clear cart
export const clearCart = async () => {
  try {
    const response = await api.delete('/cart');
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to clear cart');
  }
};